package com.example.absensiumum;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, listBox;
    EditText nameInput;
    TextView summary;
    String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()); }
    String now() { return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        buildUI();
        refresh();
    }
    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xff172033); if(bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(6)); return t;
    }
    Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(v -> r.run()); return b;
    }
    void buildUI() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(20),dp(18),dp(20));
        root.setBackgroundColor(0xfff4f7fb); scroll.addView(root); setContentView(scroll);
        root.addView(text("ABSENSI UMUM", 24, true));
        root.addView(text("Catat kehadiran dan pantau rekap dengan mudah.", 14, false));
        summary = text("", 15, true); root.addView(summary);
        root.addView(text("Tambah orang", 18, true));
        nameInput = new EditText(this); nameInput.setSingleLine(true); nameInput.setHint("Masukkan nama lengkap");
        root.addView(nameInput);
        root.addView(button(" + Tambahkan nama", () -> {
            String n = nameInput.getText().toString().trim();
            if(n.isEmpty()) { toast("Nama belum diisi"); return; }
            db.addPerson(n); nameInput.setText(""); refresh(); toast("Nama ditambahkan");
        }));
        root.addView(text("Daftar absensi hari ini", 18, true));
        TextView info = text("Pilih status untuk setiap orang. Waktu dicatat otomatis.", 13, false); root.addView(info);
        listBox = new LinearLayout(this); listBox.setOrientation(1); root.addView(listBox);
        root.addView(text("Laporan", 18, true));
        root.addView(button("Lihat rekap bulan ini", () -> showReport()));
        root.addView(button("Ekspor seluruh data ke CSV", () -> exportCSV()));
        root.addView(text("Data tersimpan di perangkat ini (offline). Ekspor CSV dapat dibuka dengan Excel atau Google Sheets.", 12, false));
    }
    void refresh() {
        listBox.removeAllViews();
        Cursor people = db.people();
        int hadir=0, izin=0, sakit=0, belum=0;
        while(people.moveToNext()) {
            int id=people.getInt(0); String name=people.getString(1);
            String status=db.statusToday(id);
            if("Hadir".equals(status)) hadir++; else if("Izin".equals(status)) izin++; else if("Sakit".equals(status)) sakit++; else belum++;
            LinearLayout card = new LinearLayout(this); card.setOrientation(1);
            card.setPadding(dp(12),dp(8),dp(12),dp(8)); card.setBackgroundColor(0xffffffff);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(5),0,dp(5)); card.setLayoutParams(cp);
            card.addView(text(name,17,true));
            TextView st = text(status.isEmpty() ? "Belum absen hari ini" : "Status: "+status,13,false); card.addView(st);
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(0);
            for(String s : new String[]{"Hadir","Izin","Sakit"}) {
                Button btn = new Button(this); btn.setText(s); btn.setTextSize(11);
                btn.setOnClickListener(v -> { db.mark(id,s,today(),now()); refresh(); toast(name+": "+s); });
                actions.addView(btn, new LinearLayout.LayoutParams(0,-2,1));
            }
            Button remove = new Button(this); remove.setText("Hapus"); remove.setTextSize(10);
            remove.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Hapus nama?")
                .setMessage("Hapus "+name+" beserta riwayat absensinya?")
                .setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{db.deletePerson(id);refresh();}).show());
            actions.addView(remove);
            card.addView(actions); listBox.addView(card);
        }
        people.close();
        summary.setText("Hari ini • "+today()+"\\nHadir: "+hadir+"   Izin: "+izin+"   Sakit: "+sakit+"   Belum: "+belum);
    }
    void showReport() {
        String month = new SimpleDateFormat("yyyy-MM",Locale.getDefault()).format(new Date());
        Cursor c = db.monthReport(month);
        StringBuilder out = new StringBuilder("Rekap "+month+"\\n\\n");
        while(c.moveToNext()) out.append(c.getString(0)).append("\\n  Hadir: ").append(c.getInt(1))
            .append(" | Izin: ").append(c.getInt(2)).append(" | Sakit: ").append(c.getInt(3)).append("\\n\\n");
        c.close();
        new AlertDialog.Builder(this).setTitle("Rekap Bulanan").setMessage(out.length()>0?out.toString():"Belum ada data.")
            .setPositiveButton("Tutup",null).show();
    }
    void exportCSV() {
        try {
            File dir = getExternalFilesDir(null);
            File file = new File(dir,"laporan_absensi.csv");
            Cursor c = db.allRecords();
            FileOutputStream fos = new FileOutputStream(file);
            StringBuilder csv = new StringBuilder("Nama,Tanggal,Jam,Status\\n");
            while(c.moveToNext()) {
                csv.append(quote(c.getString(0))).append(",").append(c.getString(1)).append(",")
                    .append(c.getString(2)).append(",").append(c.getString(3)).append("\\n");
            }
            c.close(); fos.write(csv.toString().getBytes("UTF-8")); fos.close();
            Intent share = new Intent(Intent.ACTION_SEND); share.setType("text/csv");
            share.putExtra(Intent.EXTRA_STREAM, android.net.Uri.fromFile(file));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            // Use Android Sharesheet with text as a reliable fallback for app-private file storage.
            share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT,csv.toString());
            startActivity(Intent.createChooser(share,"Bagikan laporan CSV"));
        } catch(Exception e) { toast("Gagal mengekspor: "+e.getMessage()); }
    }
    String quote(String s) { return "\""+s.replace("\"","\"\"")+"\""; }
    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    static class DB extends SQLiteOpenHelper {
        DB(Context c) { super(c,"absensi.db",null,1); }
        public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL)");
            d.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT,person_id INTEGER,date TEXT,time TEXT,status TEXT, UNIQUE(person_id,date))");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n) {}
        void addPerson(String n) { ContentValues v=new ContentValues();v.put("name",n);getWritableDatabase().insert("people",null,v); }
        Cursor people() { return getReadableDatabase().rawQuery("SELECT id,name FROM people ORDER BY name",null); }
        void deletePerson(int id) { getWritableDatabase().delete("attendance","person_id=?",new String[]{""+id});getWritableDatabase().delete("people","id=?",new String[]{""+id}); }
        void mark(int id,String s,String date,String time) {
            ContentValues v=new ContentValues();v.put("person_id",id);v.put("date",date);v.put("time",time);v.put("status",s);
            getWritableDatabase().insertWithOnConflict("attendance",null,v,SQLiteDatabase.CONFLICT_REPLACE);
        }
        String statusToday(int id) {
            Cursor c=getReadableDatabase().rawQuery("SELECT status FROM attendance WHERE person_id=? AND date=?",new String[]{""+id,new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date())});
            String s=c.moveToFirst()?c.getString(0):"";c.close();return s;
        }
        Cursor monthReport(String m) {
            return getReadableDatabase().rawQuery("SELECT p.name, SUM(a.status='Hadir'), SUM(a.status='Izin'), SUM(a.status='Sakit') FROM people p LEFT JOIN attendance a ON p.id=a.person_id AND a.date LIKE ? GROUP BY p.id ORDER BY p.name",new String[]{m+"%"});
        }
        Cursor allRecords() {
            return getReadableDatabase().rawQuery("SELECT p.name,a.date,a.time,a.status FROM attendance a JOIN people p ON p.id=a.person_id ORDER BY a.date DESC,p.name",null);
        }
    }
}
