# Absensi Umum — Android

Aplikasi Android sederhana untuk pencatatan absensi umum secara offline.

## Fitur
- Tambah dan hapus nama peserta.
- Tandai status Hadir, Izin, atau Sakit; tanggal dan jam dicatat otomatis.
- Ringkasan kehadiran hari ini.
- Rekap bulanan per orang.
- Ekspor/berbagi laporan CSV.

## Cara membuka dan membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `AbsensiUmumAndroid` melalui Android Studio.
3. Tunggu Gradle Sync selesai (Android Studio mungkin meminta memasang Android SDK 35).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK hasil build dapat ditemukan melalui notifikasi Build atau di `app/build/outputs/apk/debug/`.

## Catatan
- Data tersimpan lokal di perangkat, tanpa akun dan tanpa sinkronisasi online.
- Untuk laporan, tombol ekspor membuka menu berbagi dengan isi CSV. Simpan/kirim dari aplikasi yang tersedia.
- Ini adalah proyek sumber Android Studio, bukan APK yang sudah dikompilasi.
